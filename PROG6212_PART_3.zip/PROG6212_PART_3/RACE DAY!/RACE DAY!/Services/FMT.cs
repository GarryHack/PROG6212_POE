﻿namespace RaceDay.Web.Services;

public static class Fmt
{
    public static string Date(DateOnly d) => d.ToString("dd MMM yyyy");
    public static string Time(TimeSpan t) => $"{(int)t.TotalHours:00}:{t.Minutes:00}:{t.Seconds:00}";
    public static string Km(decimal d) => d.ToString("0.##") + " km";

    public static string Ordinal(int n)
    {
        var lastTwo = n % 100;
        if (lastTwo is >= 11 and <= 13) return n + "th";
        return (n % 10) switch { 1 => n + "st", 2 => n + "nd", 3 => n + "rd", _ => n + "th" };
    }

    public static string StatusClass(string? status) => (status ?? "").ToLowerInvariant() switch
    {
        "confirmed" => "status-confirmed",
        "pending" => "status-pending",
        "cancelled" => "status-cancelled",
        _ => "status-pending"
    };
}
